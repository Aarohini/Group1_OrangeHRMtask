export type LeaveScenario = 'positive' | 'negative' | 'boundary';

export interface LeaveData {
  tcId: string;
  scenario: LeaveScenario;
  leaveType: string;
  fromDate: string;
  toDate: string;
  comment?: string;
  expectedValidationText?: string | RegExp;
}
