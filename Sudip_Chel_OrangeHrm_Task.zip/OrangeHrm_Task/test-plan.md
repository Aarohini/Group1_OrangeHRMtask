# Combined Leave Test Plan

## Application Overview

Combined test plan: Apply Leave and My Leave List scenarios for OrangeHRM Leave Management.

## Test Scenarios

### 1. Leave Management - Apply Leave

**Seed:** `tests/seed.spec.ts`

#### 1.1. TC-001 - Positive: Apply valid leave request

**File:** `tests/leave-apply-positive.spec.ts`

**Steps:**
  1. Log in as Admin and navigate to Leave > Apply.
    - expect: Apply Leave form is visible.
  2. Select a valid Leave Type and enter From Date = 2026-09-12 and To Date = 2026-09-13 (yyyy-dd-mm).
    - expect: Dates accept yyyy-dd-mm format and Leave Type is selected.
  3. Add optional comment and click Apply.
    - expect: Leave request submission completes without validation errors.
  4. Verify success state in UI (confirmation or record appears).
    - expect: Leave request is recorded and UI shows successful submission.

#### 1.2. TC-002 - Negative: Missing Leave Type validation

**File:** `tests/leave-apply-negative.spec.ts`

**Steps:**
  1. Log in and open Apply Leave; leave Leave Type unselected.
    - expect: Apply Leave form is visible with Leave Type blank.
  2. Enter From Date = 2026-09-12 and To Date = 2026-09-13 (yyyy-dd-mm) and click Apply.
    - expect: Form submission triggers validation feedback from the application.
  3. Assert observed validation message (use live app text rather than assumed string).
    - expect: UI shows the actual validation message (e.g., 'To date should be after from date' or other live text).

#### 1.3. TC-003 - Boundary: Same-day From Date equals To Date

**File:** `tests/leave-apply-boundary.spec.ts`

**Steps:**
  1. Open Apply Leave, select a valid Leave Type, set From Date = To Date = 2026-09-12 (yyyy-dd-mm).
    - expect: Form accepts same-day date inputs.
  2. Click Apply and observe application behavior for same-day duration.
    - expect: The app either accepts the same-day request or shows the live boundary validation; test asserts observed behavior.

### 2. My Leave List

**Seed:** `tests/seed.spec.ts`

#### 2.1. TC-ML-001 - View My Leave List

**File:** `tests/leave/my-leave-view.spec.ts`

**Steps:**
  1. Log in as Admin and navigate to Leave > My Leave > My Leave List.
    - expect: User is authenticated and My Leave List page is displayed.
  2. Verify the My Leave List table is visible with columns Date, No. of Hours, Leave Type, Status, Comments.
    - expect: Table and expected columns are present and visible.
  3. If entries exist, assert each row contains a valid date in yyyy-dd-mm format and a non-empty status.
    - expect: All visible rows show Date in yyyy-dd-mm format and a valid Status value.
  4. If no entries exist, assert the UI shows a clear empty-state message (e.g., 'No Records Found').
    - expect: Appropriate empty-state message is displayed when there are no leave records.

#### 2.2. TC-ML-002 - Filter My Leave List by Date Range

**File:** `tests/leave/my-leave-filter.spec.ts`

**Steps:**
  1. Open My Leave List.
    - expect: My Leave List page is visible.
  2. Enter From Date = 2026-10-05 and To Date = 2026-10-10 (format yyyy-dd-mm) in the filter controls and apply the filter.
    - expect: Filter fields accept dates in yyyy-dd-mm format and the filter action completes.
  3. Assert that returned rows only contain dates within the requested inclusive range.
    - expect: Every displayed row's Date is >= 2026-10-05 and <= 2026-10-10.
  4. If no rows match, assert the UI shows the empty-state message.
    - expect: Empty-state is displayed when no records match the filter.
  5. Negative check: enter an invalid range where From Date > To Date and apply the filter.
    - expect: The application shows validation feedback or no results and does not crash.

#### 2.3. TC-ML-003 - Withdraw / Cancel Leave from My Leave List (Edge/Negative)

**File:** `tests/leave/my-leave-withdraw.spec.ts`

**Steps:**
  1. Open My Leave List and locate a leave entry with status 'Pending Approval' or 'Approved'.
    - expect: A matching leave entry is located or test prepares data that creates one.
  2. Attempt to withdraw/cancel the selected leave by clicking the withdraw/delete action and confirming.
    - expect: If allowed, the entry moves to a withdrawn/cancelled state and a success message appears.
  3. If the selected leave is not withdrawable (e.g., already approved or beyond allowed window), assert the application shows an appropriate warning or error message.
    - expect: The UI displays a clear failure/warning message (e.g., 'Failed to Submit' or a non-dismissible warning) and the entry remains unchanged.
  4. Validate that UI state and backend effects (where accessible) are consistent after the action.
    - expect: The entry status and any visible counts reflect the post-action state consistently.
