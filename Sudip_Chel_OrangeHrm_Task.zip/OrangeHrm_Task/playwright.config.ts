import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/leave',
  fullyParallel: false,
  workers: 1,
  reporter: [['list'], ['html']],
  use: {
    baseURL: process.env.ORANGEHRM_BASE_URL ?? 'https://opensource-demo.orangehrmlive.com',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
