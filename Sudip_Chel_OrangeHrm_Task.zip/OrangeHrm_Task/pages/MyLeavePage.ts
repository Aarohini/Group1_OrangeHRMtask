import { expect, Locator, Page } from '@playwright/test';

export class MyLeavePage {
  constructor(private readonly page: Page) {}

  async goto(): Promise<void> {
    // Ensure Leave module is available and then open My Leave in the topbar.
    const leaveModuleLink = this.page.getByRole('link', { name: 'Leave' }).first();
    if ((await leaveModuleLink.count()) > 0) {
      await leaveModuleLink.first().click().catch(() => {});
    }

    const myLeaveLink = this.page.getByRole('link', { name: 'My Leave' }).first();
    await myLeaveLink.waitFor({ state: 'visible', timeout: 10000 });
    await myLeaveLink.scrollIntoViewIfNeeded();
    await myLeaveLink.click({ timeout: 10000 }).catch(async () => {
      // fallback: try clicking via JS if normal click is blocked
      await this.page.evaluate((text) => {
        const el = Array.from(document.querySelectorAll('a')).find(a => a.textContent?.trim() === text);
        (el as HTMLElement | undefined)?.click();
      }, 'My Leave');
    });

    // Wait for page heading that indicates My Leave List is visible.
    await expect(this.page.getByRole('heading', { name: /My Leave List|My Leave/i })).toBeVisible({ timeout: 10000 });
  }

  async setFromDate(date: string): Promise<void> {
    const inputs = this.page.getByPlaceholder('yyyy-dd-mm');
    await expect(inputs.first()).toBeVisible({ timeout: 5000 });
    await inputs.nth(0).fill(date);
  }

  async setToDate(date: string): Promise<void> {
    const inputs = this.page.getByPlaceholder('yyyy-dd-mm');
    await expect(inputs.first()).toBeVisible({ timeout: 5000 });
    await inputs.nth(1).fill(date);
  }

  async clickSearch(): Promise<void> {
    await this.page.getByRole('button', { name: /Search/i }).click();
  }

  async clickReset(): Promise<void> {
    await this.page.getByRole('button', { name: /Reset/i }).click();
  }

  getResultRows(): Locator {
    return this.page.locator('table tbody tr');
  }

  async hasEmptyStateMessage(): Promise<boolean> {
    const empty = this.page.getByText(/No Records Found|No Records to display|No records/i);
    return (await empty.count()) > 0;
  }

  async extractDateFromRow(rowLocator: Locator): Promise<string> {
    const firstCell = rowLocator.locator('td').nth(0);
    return (await firstCell.textContent())?.trim() ?? '';
  }
}
