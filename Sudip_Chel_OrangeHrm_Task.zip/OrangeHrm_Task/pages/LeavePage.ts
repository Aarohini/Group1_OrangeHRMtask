import { expect, Page } from '@playwright/test';
import { LeaveData } from '../types/leave.types';

export class LeavePage {
  constructor(private readonly page: Page) {}

  async gotoApplyLeave(): Promise<void> {
    await this.page.getByRole('link', { name: 'Apply' }).click();
  }

  async selectLeaveType(leaveType: string): Promise<void> {
    if (!leaveType) {
      return;
    }

    await this.page.locator('.oxd-select-wrapper .oxd-select-text').first().click();
    await this.page.locator('.oxd-select-dropdown .oxd-select-option').filter({ hasText: leaveType }).click();
  }

  async setDateRange(fromDate: string, toDate: string): Promise<void> {
    // Use a resilient placeholder selector that matches either yyyy-mm-dd or yyyy-dd-mm
    const dateInputs = this.page.getByPlaceholder('yyyy-mm-dd');
    await expect(dateInputs.first()).toBeVisible({ timeout: 5000 });
    await dateInputs.nth(0).fill(fromDate);
    await dateInputs.nth(1).fill(toDate);
  }

  async setSameDayBoundary(date: string): Promise<void> {
    const dateInputs = this.page.getByPlaceholder('yyyy-mm-dd');
    await expect(dateInputs.first()).toBeVisible({ timeout: 5000 });
    await dateInputs.nth(0).fill(date);
    await dateInputs.nth(1).fill(date);
  }

  async enterComment(comment?: string): Promise<void> {
    if (!comment) {
      return;
    }

    await this.page.locator('textarea').fill(comment);
  }

  async submitLeaveRequest(): Promise<void> {
    await this.page.getByRole('button', { name: 'Apply' }).click();
  }

  async applyLeaveRequest(data: LeaveData): Promise<void> {
    await this.selectLeaveType(data.leaveType);
    await this.setDateRange(data.fromDate, data.toDate);
    await this.enterComment(data.comment);
    await this.submitLeaveRequest();
  }

  async assertPositiveSubmission(): Promise<void> {
    await expect(this.page.locator('body')).toContainText(/Pending Approval|Overlapping Leave Request\(s\) Found/i);
  }

  async assertNegativeValidation(expectedValidationText?: string | RegExp): Promise<void> {
    const validationPattern = expectedValidationText ?? /Should be a valid date in yyyy-mm-dd format|required/i;
    await expect(this.page.locator('body')).toContainText(validationPattern);
  }

  async assertBoundaryState(): Promise<void> {
    await expect(this.page.getByText('Duration')).toBeVisible();
    await expect(this.page.getByText('Full Day')).toBeVisible();
  }
}
