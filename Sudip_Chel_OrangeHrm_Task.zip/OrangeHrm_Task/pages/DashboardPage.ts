import { Page } from '@playwright/test';

export class DashboardPage {
  constructor(private readonly page: Page) {}

  async navigateToLeave(): Promise<void> {
    await this.page.getByRole('link', { name: 'Leave' }).click();
  }
}
