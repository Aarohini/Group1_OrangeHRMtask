// spec: test-plan.md
// seed: tests/seed.spec.ts

import { test, expect } from '../../fixtures/testFixtures';
import { MyLeavePage } from '../../pages/MyLeavePage';
import { myLeaveData } from '../../test-data/myLeaveData';

test.describe('My Leave List', () => {
  test('TC-ML-001 - View My Leave List (Positive)', async ({ leavePage, page }) => {
    const data = myLeaveData.positive;
    const myLeave = new MyLeavePage(page);

    await myLeave.goto();
    await myLeave.setFromDate(data.fromDate);
    await myLeave.setToDate(data.toDate);
    await myLeave.clickSearch();

    const rows = myLeave.getResultRows();
    const count = await rows.count();

    if (count === 0) {
      const hasEmpty = await myLeave.hasEmptyStateMessage();
      expect(hasEmpty).toBe(true);
    } else {
      expect(count).toBeGreaterThan(0);
      for (let i = 0; i < count; i++) {
        const row = rows.nth(i);
        const dateText = await myLeave.extractDateFromRow(row);
        expect(dateText).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      }
    }
  });

  test('TC-ML-002 - Filter My Leave List by Date Range (Negative)', async ({ leavePage, page }) => {
    const data = myLeaveData.negative;
    const myLeave = new MyLeavePage(page);

    await myLeave.goto();
    await myLeave.setFromDate(data.fromDate);
    await myLeave.setToDate(data.toDate);
    await myLeave.clickSearch();

    const rows = myLeave.getResultRows();
    const count = await rows.count();

    const hasEmpty = await myLeave.hasEmptyStateMessage();
    expect(count === 0 || hasEmpty).toBeTruthy();
  });

  test('TC-ML-003 - Withdraw / Single-day boundary (Boundary)', async ({ leavePage, page }) => {
    const data = myLeaveData.boundary;
    const myLeave = new MyLeavePage(page);

    await myLeave.goto();
    await myLeave.setFromDate(data.fromDate);
    await myLeave.setToDate(data.toDate);
    await myLeave.clickSearch();

    const rows = myLeave.getResultRows();
    const count = await rows.count();

    const hasEmpty = await myLeave.hasEmptyStateMessage();
    expect(count >= 0).toBeTruthy();
    expect(hasEmpty || count > 0).toBeTruthy();
  });
});
