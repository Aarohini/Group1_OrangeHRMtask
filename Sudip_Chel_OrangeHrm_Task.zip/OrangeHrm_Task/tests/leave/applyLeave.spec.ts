import { test, expect } from '../../fixtures/testFixtures';
import { leaveData } from '../../test-data/leaveData';

test.describe('Leave Management - Apply Leave', () => {
  test('TC_APPLYLEAVE_001 - Positive Test Case: Apply a valid leave request', async ({ leavePage }) => {
    const data = leaveData.positive;

    await leavePage.applyLeaveRequest(data);
    await leavePage.assertPositiveSubmission();
  });

  test('TC_APPLYLEAVE_002 - Negative Test Case: Mandatory-field validation when Leave Type is not selected', async ({ leavePage }) => {
    const data = leaveData.negative;

    await leavePage.setDateRange(data.fromDate, data.toDate);
    await leavePage.enterComment(data.comment);
    await leavePage.submitLeaveRequest();
    await leavePage.assertNegativeValidation(data.expectedValidationText);
  });

  test('TC_APPLYLEAVE_003 - Boundary Test Case: Minimum leave-duration boundary when From Date equals To Date', async ({ leavePage }) => {
    const data = leaveData.boundary;

    await leavePage.selectLeaveType(data.leaveType);
    await leavePage.setSameDayBoundary(data.fromDate);
    await leavePage.submitLeaveRequest();
    await leavePage.assertBoundaryState();
  });
});
