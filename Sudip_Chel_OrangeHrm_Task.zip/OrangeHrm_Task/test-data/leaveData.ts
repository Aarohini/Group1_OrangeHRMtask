import { LeaveData } from '../types/leave.types';

// Hard-coded dates for October 2026.
// Note: the application uses the placeholder format `yyyy-dd-mm` (year-day-month).
export const leaveData: Record<string, LeaveData> = {
  positive: {
    tcId: 'TC_APPLYLEAVE_001',
    scenario: 'positive',
    leaveType: 'US - Bereavement',
    // From: 5 Oct 2026, To: 7 Oct 2026 (yyyy-dd-mm)
    fromDate: '2026-05-10',
    toDate: '2026-07-10',
    comment: 'Personal leave request',
  },
  negative: {
    tcId: 'TC_APPLYLEAVE_002',
    scenario: 'negative',
    leaveType: '',
    // From: 9 Oct 2026, To: 11 Oct 2026 (yyyy-dd-mm)
    fromDate: '2026-09-10',
    toDate: '2026-11-10',
    comment: 'Leave request without Leave Type',
    expectedValidationText: /Should be a valid date in yyyy-dd-mm format|required/i,
  },
  boundary: {
    tcId: 'TC_APPLYLEAVE_003',
    scenario: 'boundary',
    leaveType: 'US - Bereavement',
    // Single day: 12 Oct 2026 (yyyy-dd-mm)
    fromDate: '2026-12-10',
    toDate: '2026-12-10',
    comment: 'One-day leave boundary',
  },
};
