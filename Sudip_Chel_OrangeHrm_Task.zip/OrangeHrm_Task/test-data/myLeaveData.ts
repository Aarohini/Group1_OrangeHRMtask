export interface MyLeaveSearchData {
  tcId: string;
  fromDate: string; // yyyy-dd-mm
  toDate: string; // yyyy-dd-mm
  status?: string;
  leaveType?: string;
}

export const myLeaveData: Record<string, MyLeaveSearchData> = {
  positive: {
    tcId: 'TC-ML-001',
    fromDate: '2026-14-09',
    toDate: '2026-14-09',
  },
  negative: {
    tcId: 'TC-ML-002',
    fromDate: '2026-01-01',
    toDate: '2026-01-02',
  },
  boundary: {
    tcId: 'TC-ML-003',
    fromDate: '2026-05-10',
    toDate: '2026-05-10',
  },
};
