import { test as base, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { LeavePage } from '../pages/LeavePage';

type AppFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  leavePage: LeavePage;
};

export const test = base.extend<AppFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },

  leavePage: async ({ page }, use) => {
    const username = 'Admin';
    const password = 'admin123';

    if (!username || !password) {
      throw new Error('Set ORANGEHRM_USERNAME and ORANGEHRM_PASSWORD before running OrangeHRM tests.');
    }

    const loginPage = new LoginPage(page);
    const dashboardPage = new DashboardPage(page);
    const leavePage = new LeavePage(page);

    await loginPage.goto();
    await loginPage.login(username, password);
    await dashboardPage.navigateToLeave();
    await leavePage.gotoApplyLeave();

    await use(leavePage);
  },
});

export { expect };
