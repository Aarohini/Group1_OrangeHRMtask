import { test as base } from '@playwright/test';

import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashBoard';
import { PerformancePage } from '../pages/PerformancePage';

type OrangeFixtures = {

    loginPage: LoginPage;
    dashboardPage: DashboardPage;
    performancePage: PerformancePage;
};

export const test = base.extend<OrangeFixtures>({

    loginPage: async ({ page }, use) => {

        await use(new LoginPage(page));
    },

    dashboardPage: async ({ page }, use) => {

        await use(new DashboardPage(page));
    },

    performancePage: async ({ page }, use) => {

        await use(new PerformancePage(page));
    }
});

export { expect } from '@playwright/test';