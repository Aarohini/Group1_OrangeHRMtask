## MANUAL TEST ARTIFACTS PROMPT



I am working on a QA Test Automation project for the Booking.com website.



Module: 'Stays'



Create professional and realistic documentation for the Stays module . Include the following sections:



1\. Epic

&#x20;  - Create 1 Epic only: "Stays"



2\. User Stories

&#x20;  - Create 7-10 user stories using the format:

&#x20;    "As a traveler, I want to \_\_\_\_\_ so that \_\_\_\_\_."



3\. Sub-Stories

&#x20;  - Create 2-3 relevant sub-stories under appropriate user stories.



4\. Test Scenarios

&#x20;  - Generate positive, negative, validation, usability, accessibility, and boundary test scenarios for each user story.



5\. Test Cases

&#x20;  For each test scenario provide:

&#x20;  - Test Case ID

&#x20;  - Test Case Title

&#x20;  - Preconditions

&#x20;  - Test Steps

&#x20;  - Test Data

&#x20;  - Expected Result

&#x20;  - Priority (High/Medium/Low)



Requirements:

\- Content should look manually written by a QA Engineer.

\- Use realistic Booking.com Stays functionality such as:

&#x20; - Destination search

&#x20; - Date selection

&#x20; - Guest selection

&#x20; - Property listing

&#x20; - Filters

&#x20; - Sorting

&#x20; - Property details

&#x20; - Room selection

&#x20; - Booking

&#x20; - Booking confirmation

&#x20; - Booking management

\- Generate at least 6-7 test scenarios and 20-21 test cases.

\- Keep the language simple, and professional.





### ORANGEHRM PROJECT PROMPT







I am automating the OrangeHRM Performance module using Playwright with TypeScript. Create a professional automation framework following the Page Object Model (POM) design pattern, using Fixtures and Data-Driven Testing (DDT) with JSON test data. The framework should cover login, navigation to the Performance module, entering employee review search details, performing the search, and validating the results. Use separate folders for Pages, Fixtures, Test Data, and Tests, follow industry-standard practices, and avoid using helper or utility classes.

