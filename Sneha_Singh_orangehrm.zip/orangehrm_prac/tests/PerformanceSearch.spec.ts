import { test, expect } from '../fixtures/baseFixture';

import performanceData from '../testdata/performanceData.json';

test.describe('Performance Module', () => {

    test('Search Employee Performance Review',
        async ({
            page,
            loginPage,
            dashboardPage,
            performancePage
        }) => {

            await loginPage.login(
                performanceData.username,
                performanceData.password
            );

            await dashboardPage.clickPerformanceMenu();

            await performancePage.searchEmployeeReview(
                performanceData.employeeName
            );
            await page.waitForTimeout(2000); // Wait for 2 seconds to ensure the search results are fully loaded

            await expect(page.locator('body'))
                .toBeVisible();
        });
});