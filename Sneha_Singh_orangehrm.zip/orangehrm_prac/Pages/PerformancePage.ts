import { Page } from '@playwright/test';

export class PerformancePage {

    constructor(private page: Page) {}

    employeeNameTextbox = () =>
        this.page.getByPlaceholder('Type for hints...').first();

    searchButton = () =>
        this.page.getByRole('button', { name: 'Search' });

    resetButton = () =>
        this.page.getByRole('button', { name: 'Reset' });

    async searchEmployeeReview(employeeName: string) {

        await this.employeeNameTextbox()
            .fill(employeeName);

        await this.searchButton()
            .click();
    }
}