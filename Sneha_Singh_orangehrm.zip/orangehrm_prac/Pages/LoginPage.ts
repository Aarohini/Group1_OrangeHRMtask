// import {Page} from '@playwright/test'

// export class LoginPage {
//   constructor(private page: Page) {}

//   async Login(username: string, password: string) {
//     await this.page.getByPlaceholder('Username').waitFor({ state: 'visible' });
//     await this.page.getByPlaceholder('Username').fill(username);
//     await this.page.getByPlaceholder('Password').fill(password);
//     await this.page.getByRole('button', { name: 'Login' }).click();
//   }
// }



import { Page } from '@playwright/test';

export class LoginPage {

    constructor(private page: Page) {}

    async login(username: string, password: string) {

        await this.page.goto(
            'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
        );

        await this.page.locator('input[name="username"]')
            .fill(username);

        await this.page.locator('input[name="password"]')
            .fill(password);

        await this.page.locator('button[type="submit"]')
            .click();
    }
}