// import {Page} from '@playwright/test'

// export class DashBoard {
//     constructor(private page: Page) {}

//     async clickTimeMenu() {
//         // await this.page.getByText('Time').nth(1).click();
//         await this.page.getByRole('link', { name: 'Time' }).click();
//     }
// }



import { Page } from '@playwright/test';

export class DashboardPage {

    constructor(private page: Page) {}

    async clickPerformanceMenu() {

        await this.page.getByText('Performance')
            .click();
    }
}