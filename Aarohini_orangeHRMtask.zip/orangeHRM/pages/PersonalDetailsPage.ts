import { Page } from '@playwright/test';

export class PersonalDetailsPage {
    constructor(private page: Page) {}

    private genderFemale = () =>
        this.page.getByRole('radio', { name: 'Female' });

    private nationalityDropdown = () =>
        this.page.locator('.oxd-select-text').first();

    private dateOfBirthCalendar = () =>
        this.page.locator('.oxd-date-input .oxd-icon').first();

    private employeeFormSaveBtn = () =>
        this.page
            .locator('form')
            .first()
            .getByRole('button', { name: 'Save' });

    async updatePersonalDetails() {
        await this.genderFemale().check();

        await this.employeeFormSaveBtn().click();
    }
}