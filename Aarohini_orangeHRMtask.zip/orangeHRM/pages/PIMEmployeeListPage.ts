import { expect, Page } from '@playwright/test';

export type EmployeeSearch = {
  name: string;
  id: string;
};

export class PIMEmployeeListPage {
  constructor(private page: Page) {}

  private readonly pimListUrl =
    'https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList';

  private pimMenu = () =>
    this.page.getByRole('link', { name: 'PIM' });

  private employeeId = () =>
    this.page.locator(
      "//label[text()='Employee Id']/../following-sibling::div/input"
    );

  private searchBtn = () =>
    this.page.getByRole('button', { name: 'Search' });

  private deleteBtn = () =>
    this.page.getByRole('button', { name: /Delete Selected/i });

  private confirmDeleteBtn = () =>
    this.page.getByRole('button', { name: /Yes, Delete/i });

  async openPIM() {
    await this.pimMenu().click();
    try {
      await this.page.waitForURL(/pim\/viewEmployeeList/, { waitUntil: 'domcontentloaded', timeout: 10000 });
    } catch {
      await this.pimMenu().click();
      await this.page.waitForURL(/pim\/viewEmployeeList/, { waitUntil: 'domcontentloaded', timeout: 10000 });
    }

    const employeeInformation = this.page.getByRole('heading', { name: 'Employee Information' });
    try {
      await expect(employeeInformation).toBeVisible({ timeout: 20000 });
    } catch {
      await this.page.goto(this.pimListUrl, {
        waitUntil: 'domcontentloaded',
        timeout: 30000,
      });
      await expect(employeeInformation).toBeVisible({ timeout: 20000 });
    }
  }

  async searchEmployee(employee: EmployeeSearch, selectEmployeeName = true) {
    const nameField = this.page.getByRole('textbox', { name: 'Type for hints...' }).first();
    await nameField.fill(employee.name);
    if (selectEmployeeName) {
      const matchingNames = this.page.getByRole('option', { name: employee.name, exact: true });
      await expect(matchingNames.first()).toBeVisible({ timeout: 15000 });
      await matchingNames.first().click();
    }
    await this.employeeId().fill(employee.id);
    await this.searchBtn().click();

    const noRecords = this.page.getByText('No Records Found', { exact: true }).first();
    const searchResult = this.employeeRow(employee.id).or(noRecords);
    await expect(searchResult).toBeVisible({ timeout: 30000 });

    if (selectEmployeeName && await noRecords.isVisible()) {
      await this.page.getByRole('button', { name: 'Reset' }).click();
      await this.employeeId().fill(employee.id);
      await this.searchBtn().click();
      await expect(this.employeeRow(employee.id).or(noRecords)).toBeVisible({ timeout: 30000 });
    }
  }

  async verifyEmployeeFound(empId: string) {
    await expect(this.employeeRow(empId)).toBeVisible({ timeout: 30000 });
  }

  async deleteEmployee(empId: string) {
    const row = this.employeeRow(empId);
    await row.locator('.oxd-checkbox-input').click();
    await this.deleteBtn().click();
    await expect(this.confirmDeleteBtn()).toBeVisible();
    await this.confirmDeleteBtn().click();
    await expect(this.page.getByText(/Successfully Deleted/)).toBeVisible({ timeout: 30000 });
  }

  async verifyNoRecordsFound() {
    await expect(
      this.page.getByText('No Records Found', { exact: true }).first()
    ).toBeVisible({timeout: 30000});
  }

  private employeeRow(empId: string) {
    return this.page.locator('.oxd-table-card').filter({ hasText: empId }).first();
  }
}