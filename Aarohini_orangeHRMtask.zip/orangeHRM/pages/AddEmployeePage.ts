import { expect, Page } from '@playwright/test';

export class AddEmployeePage {
  constructor(private page: Page) {}

  private firstName = () =>
    this.page.getByRole('textbox', { name: 'First Name' });

  private middleName = () =>
    this.page.getByRole('textbox', { name: 'Middle Name' });

  private lastName = () =>
    this.page.getByRole('textbox', { name: 'Last Name' });

  private employeeId = () =>
    this.page.locator(
      "//label[text()='Employee Id']/../following-sibling::div/input"
    );

  private saveBtn = () =>
    this.page.getByRole('button', { name: 'Save' });

  private addEmployeeLink = () =>
    this.page.getByRole('link', { name: 'Add Employee' });

  private formLoader = () =>
    this.page.locator('.oxd-form-loader');

  async addEmployee(
    firstName: string,
    middleName: string,
    lastName: string
  ): Promise<string> {

    await expect(this.firstName()).toBeVisible();
    const empId = await this.employeeId().inputValue();

    await this.firstName().fill(firstName);
    await this.middleName().fill(middleName);
    await this.lastName().fill(lastName);

    await expect(this.formLoader()).toBeHidden({ timeout: 30000 });
    await this.saveBtn().click();
    try {
      await this.page.waitForURL(/pim\/viewPersonalDetails/, {
        waitUntil: 'domcontentloaded',
        timeout: 30000,
      });
    } catch {
      await expect(this.formLoader()).toBeHidden({ timeout: 30000 });
      await this.saveBtn().click();
      await this.page.waitForURL(/pim\/viewPersonalDetails/, {
        waitUntil: 'domcontentloaded',
        timeout: 30000,
      });
    }
    await expect(this.page.getByRole('heading', { name: 'Personal Details' })).toBeVisible();

    return empId;
  }

  async open() {
    await this.addEmployeeLink().click();
    await expect(this.page).toHaveURL(/pim\/addEmployee/);
  }
}