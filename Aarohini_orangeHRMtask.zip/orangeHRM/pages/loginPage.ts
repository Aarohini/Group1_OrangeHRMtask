import { expect, Page } from '@playwright/test';

export class LoginPage {
    constructor(private page: Page) {}
    
//locators
    private username = () =>
        this.page.getByRole('textbox', { name: 'Username' });

    private password = () =>
        this.page.getByRole('textbox', { name: 'Password' });

    private loginBtn = () =>
        this.page.getByRole('button', { name: 'Login' });


    //functions
    async navigate() {
        const loginUrl =
            'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login';

        await this.page.goto(loginUrl, {
            waitUntil: 'domcontentloaded',
            timeout: 30000,
        });

        try {
            await expect(this.loginBtn()).toBeVisible({ timeout: 15000 });
        } catch {
            await this.page.reload({
                waitUntil: 'domcontentloaded',
                timeout: 30000,
            });
            await expect(this.loginBtn()).toBeVisible({ timeout: 15000 });
        }
    }

    async login(username: string, password: string) {
        await this.username().fill(username);
        await this.password().fill(password);
        await this.loginBtn().click();
        try {
            await this.page.waitForURL(/dashboard\/index/, {
                waitUntil: 'domcontentloaded',
                timeout: 15000,
            });
        } catch {
            await this.loginBtn().click();
            await this.page.waitForURL(/dashboard\/index/, {
                waitUntil: 'domcontentloaded',
                timeout: 15000,
            });
        }
    }
}