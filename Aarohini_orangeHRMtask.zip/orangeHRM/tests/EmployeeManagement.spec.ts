import { test } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { PIMEmployeeListPage } from '../pages/PIMEmployeeListPage';
import { AddEmployeePage } from '../pages/AddEmployeePage';

type EmployeeData = {
  firstName: string;
  middleName: string;
  lastName: string;
};

const employeeData = require('../data/employeeData.json') as EmployeeData[];

test.describe.configure({ mode: 'serial' });

for (const employee of employeeData) {
  test(`Create and delete employee: ${employee.firstName} ${employee.lastName}`, async ({ page }) => {
  test.setTimeout(120000);

  const loginPage = new LoginPage(page);
  const pimPage = new PIMEmployeeListPage(page);
  const addEmployeePage = new AddEmployeePage(page);

  await loginPage.navigate();

  await loginPage.login(
    'Admin',
    'admin123'
  );
//Open PIM

  await pimPage.openPIM();

  await addEmployeePage.open();

  const employeeId =
    await addEmployeePage.addEmployee(
      employee.firstName,
      employee.middleName,
      employee.lastName
    );

  console.log(`Created Employee ID = ${employeeId}`);

  //Goback Employee List

  await pimPage.openPIM();

  //-----------------------
  // Search Employee
  //-----------------------

  const employeeName = `${employee.firstName} ${employee.middleName} ${employee.lastName}`;
  await pimPage.searchEmployee({ name: employeeName, id: employeeId });

  await pimPage.verifyEmployeeFound(employeeId);

  //Delete Employee

  await pimPage.deleteEmployee(employeeId);

  //Verify Deletion

  await pimPage.searchEmployee({ name: employeeName, id: employeeId }, false);

  await pimPage.verifyNoRecordsFound();
  });
}