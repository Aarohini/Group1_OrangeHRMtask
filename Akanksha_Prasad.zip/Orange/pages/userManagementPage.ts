import { Page, Locator, expect } from '@playwright/test';

export class UserManagementPage {

    readonly page: Page;

    // Search fields
    readonly usernameInput: Locator;
    readonly userRoleDropdown: Locator;
    readonly employeeNameInput: Locator;
    readonly statusDropdown: Locator;

    // Buttons
    readonly searchButton: Locator;
    readonly resetButton: Locator;

    // Search results
    readonly resultTable: Locator;

    constructor(page: Page) {
        this.page = page;

        // this.usernameInput = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'Username' }).getByRole('textbox');
        this.usernameInput = page.locator("//input[@class='oxd-input oxd-input--active']").nth(1);

        // this.userRoleDropdown = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'User Role' }).getByRole('combobox');
        this.userRoleDropdown = page.locator("i.oxd-select-text--arrow").first();

        this.employeeNameInput = page.getByPlaceholder('Type for hints...');

        // this.statusDropdown = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'Status' }).getByRole('combobox');
        this.statusDropdown = page.locator("i.oxd-select-text--arrow").nth(1);

        this.searchButton = page.getByRole('button', {
            name: 'Search'
        });

        this.resetButton = page.getByRole('button', {
            name: 'Reset'
        });

        this.resultTable = page.locator('.oxd-table');
    }

    async searchByUsername(username: string) {
        await this.usernameInput.fill(username);
    }

    async selectUserRole(role: string) {
        await this.userRoleDropdown.click();

        await this.page.getByRole('option', {
            name: role,
            exact: true
        }).click();
    }

    async selectEmployee(employeeName: string) {
        await this.employeeNameInput.fill(employeeName);
        await this.page.getByRole('option', { name: 'Rahul Das' }).first().click();

        // await this.page.getByRole('option', {
        //     name: employeeName,
        //     exact: true
        // }).click();
    }

    async selectStatus(status: string) {
        await this.statusDropdown.click();
        await this.page.locator("//div[text()='Enabled']").first().click();

        // await this.page.getByRole('option', {
        //     name: "Enabled",
        //     exact: true
        // }).click();
    }

    async clickSearch() {
        await this.searchButton.click();
    }

    async searchUser(
        username: string,
        role: string,
        employeeName: string,
        status: string
    ) {
        await this.searchByUsername(username);
        await this.selectUserRole(role);
        await this.selectEmployee(employeeName);
        await this.selectStatus(status);

        await this.clickSearch();
    }

    async verifyUserExists(username: string) {
        await expect(
            this.page.getByRole('cell', { name: username, exact: true })
        ).toBeVisible();
    }
}