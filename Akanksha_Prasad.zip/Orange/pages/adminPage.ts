import { Page, Locator } from '@playwright/test';

export class AdminPage {

    readonly page: Page;

    // Navigation
    readonly adminMenu: Locator;
    readonly addButton: Locator;

    // User creation fields
    readonly userRoleDropdown: Locator;
    readonly employeeNameInput: Locator;
    readonly statusDropdown: Locator;
    readonly usernameInput: Locator;
    readonly passwordInput: Locator;
    readonly confirmPasswordInput: Locator;
    readonly saveButton: Locator;

    constructor(page: Page) {
        this.page = page;

        // Navigation
        this.adminMenu = page.getByText('Admin', { exact: true });
        this.addButton = page.getByRole('button', { name: 'Add' });

        // Form
        // this.userRoleDropdown = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'User Role' }).getByRole('combobox');
        this.userRoleDropdown = page.locator("//div[contains(@class,'oxd-select-text')][2]");

        this.employeeNameInput = page.getByPlaceholder('Type for hints...');

        // this.statusDropdown = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'Status' }).getByRole('combobox');

        this.statusDropdown = page.locator("//i[contains(@class,'oxd-select-text--arrow')]");

        // this.usernameInput = page.locator(
        //     '.oxd-form-row'
        // ).filter({ hasText: 'Username' }).getByRole('textbox');
        this.usernameInput = page.getByRole('textbox').nth(2);

        //this.passwordInput = page.getByLabel('Password').last();
        this.passwordInput = page.locator("//input[contains(@class,'oxd-input oxd-input--active')]").nth(1);

        this.confirmPasswordInput = page.locator("//input[contains(@class,'oxd-input oxd-input--active')]").nth(2);


        this.saveButton = page.getByRole('button', { name: 'Save' });
    }

    async openAdmin() {
        await this.adminMenu.click();
    }

    async clickAdd() {
        await this.addButton.click();
    }

    async selectUserRole(role: string) {
        await this.userRoleDropdown.first().click();

        await this.page.getByRole('option', {
            name: role,
            exact: true
        }).click();
    }

    async selectEmployee(employeeName: string) {
        await this.employeeNameInput.fill(employeeName);

        await this.page.getByRole('option', {
            name: employeeName,
            exact: true
        }).first().click();
    }

    async selectStatus(status: string) {
        await this.statusDropdown.nth(1).click();

        await this.page.getByRole('option', {
            name: status,
            exact: true
        }).click();
    }

    async enterUsername(username: string) {
        await this.usernameInput.fill(username);
    }

    async enterPassword(password: string) {
        await this.passwordInput.fill(password);
        await this.confirmPasswordInput.fill(password);
    }

    async saveUser() {
        await this.saveButton.click();
    }

    async createUser(
        role: string,
        employeeName: string,
        status: string,
        username: string,
        password: string
    ) {
        await this.selectUserRole(role);
        await this.selectEmployee(employeeName);
        await this.selectStatus(status);
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.saveUser();
    }
}