***Automation Testing*** 

I want to automate a user creation and verification flow on the OrangeHRM website using **Playwright with TypeScript** and follow a proper **Page Object Model (POM)** structure.

The flow should be:

1. First, log in to OrangeHRM using a valid username and password.
2. After login, go to the **Admin** section.
3. Click on the **Add** button to create a new user.
4. In the Add User page:

   * Select a **User Role**.
   * Select any available **Employee Name** from the suggestion list.
   * Set the **Status** to **Enabled**.
   * Enter a new **Username**.
   * Enter a password and confirm the password to make sure the passwords match.
   * Click **Save**.
5. Once the user is created successfully, go back to the **User Management** section.
6. Search for the newly created user using:

   * The created username
   * The same user role
   * The same employee name
   * Status as **Enabled**
7. Click **Search**.
8. Finally, verify/assert that the newly created username is displayed in the search results.

Please create a clean and beginner-friendly **POM folder structure** for this flow. Keep the page classes separate based on their responsibilities, for example Login Page, Admin/User Creation Page, and User Management Page.

Also keep the actual test flow in the test file and the locators/actions inside the respective page classes. Use **Playwright with TypeScript**, and make the structure easy to understand and maintain.
