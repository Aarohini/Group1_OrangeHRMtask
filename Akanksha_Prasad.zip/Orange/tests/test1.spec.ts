import { test } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { AdminPage } from '../pages/adminPage';
import { UserManagementPage } from '../pages/userManagementPage';

import userData from '../testData/userData.json';

test.describe('User Management DDT', () => {

    for (const user of userData) {

        test(`Create and verify user ${user.username}`, async ({ page }) => {

            const loginPage = new LoginPage(page);
            const adminPage = new AdminPage(page);
            const userManagementPage = new UserManagementPage(page);

            // Login
            await page.goto('https://opensource-demo.orangehrmlive.com/');

            await loginPage.login(
                'Admin',
                'admin123'
            );

            // Open Admin Menu
            await adminPage.openAdmin();

            // Click Add
            await adminPage.clickAdd();

            // Create User
            await adminPage.createUser(
                user.role,
                user.employeeName,
                user.status,
                user.username,
                user.password
            );

            // Search User
            await userManagementPage.searchUser(
                user.username,
                user.role,
                user.employeeName,
                user.status
            );

            // Verify User Exists
            await userManagementPage.verifyUserExists(
                user.username
            );
        });
    }
});