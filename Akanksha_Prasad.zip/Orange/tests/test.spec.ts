import { test } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { AdminPage } from '../pages/adminPage';
import { UserManagementPage } from '../pages/userManagementPage';

test('Create user and verify user in User Management', async ({ page }) => {

    const loginPage = new LoginPage(page);
    const adminPage = new AdminPage(page);
    const userManagementPage = new UserManagementPage(page);

    const username = 'siti233';
    const password = 'soso1234';

    const role = 'ESS';
    const employeeName = 'Rahul Das';
    const status = 'Enabled';

    // 1. Login
    await page.goto('https://opensource-demo.orangehrmlive.com/');

    await loginPage.login(
        'Admin',
        'admin123'
    );

    // 2. Open Admin
    await adminPage.openAdmin();

    // 3. Click Add
    await adminPage.clickAdd();

    // 4. Create user
    await adminPage.createUser(
        role,
        employeeName,
        status,
        username,
        password
    );

    // 5. Search created user
    await userManagementPage.searchUser(
        username,
        role,
        employeeName,
        status
    );

    // 6. Verify user exists
    await userManagementPage.verifyUserExists(username);
});